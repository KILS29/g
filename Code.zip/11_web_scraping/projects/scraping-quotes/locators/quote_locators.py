class QuoteLocators:
    CONTENT_LOCATOR = 'span.text'
    AUTHOR_LOCATOR = 'small.author'
    TAGS_LOCATOR = 'div.tags a.tag'
