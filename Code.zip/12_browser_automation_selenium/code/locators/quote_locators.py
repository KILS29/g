class QuoteLocators:
    CONTENT_LOCATOR = 'span.content'
    AUTHOR_LOCATOR = 'span.author'
    TAGS_LOCATOR = 'span.tag'
