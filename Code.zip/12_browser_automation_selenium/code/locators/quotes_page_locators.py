class QuotesPageLocators:
    QUOTE = 'div.quote'
    AUTHOR_DROPDOWN = 'select#author'
    TAG_DROPDOWN = 'select#tag'
    SEARCH_BUTTON = 'input[name="submit_button"]'
