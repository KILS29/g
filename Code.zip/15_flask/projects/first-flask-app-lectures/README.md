Hey there! Welcome to your first Flask app.

The completed project can be seen at https://github.com/tecladocode/first-flask-app.

The various files in this project, numbered from 1 onwards, represent different steps in implementing this first Flask app, as covered in our comprehensive Python course: [The Complete Python Course](https://www.udemy.com/the-complete-python-course/?couponCode=GITHUB).