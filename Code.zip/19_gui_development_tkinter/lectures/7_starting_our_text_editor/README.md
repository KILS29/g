# Starting our Text Editor

Brief description of project.

Image of final project that we want to create.
