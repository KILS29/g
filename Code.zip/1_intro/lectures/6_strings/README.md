# Strings and string formatting

* Strings
* f-strings
* The `.format()` method
* Multi-line strings