from typing import Union


def divide(dividend: Union[int, float], divisor: Union[int, float]):
    return dividend / divisor
