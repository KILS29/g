from libs.mailgun import Mailgun

Mailgun.send(['test@email.com'], 'Test e-mail', 'This is a test e-mail')
