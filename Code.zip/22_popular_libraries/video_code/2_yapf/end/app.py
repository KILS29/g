movies = ['The Matrix', 'Fast & Furious', 'Frozen', 'The life of Pi']

for movie in movies:
    print(movie)

print('We\'re done here!')
